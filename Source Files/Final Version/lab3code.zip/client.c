#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "unistd.h"
#include "sys/types.h"
#include "sys/socket.h"
#include "netinet/in.h"
#include "arpa/inet.h"

#define BUF 32

int main()
{
  //Variables

  struct sockaddr_in stSockAddr;
  int Res;
  int i=0;
  int flag=0;
  int flag2=3;
  //char control[BUF];
  char control;
  int CommSock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
  char message[9];//data plus end char
  char type[1];
  char freq[4];
  char amp[3];

  //Begin data entry

  printf("Please enter wave type: [p]ulse/[s]ine\r\n");
  scanf("%s",type);
  if((strcmp(type,"p") != 0) && (strcmp(type,"s")!= 0))//type is not correct
  {
    printf("Please chose between [p]ulse and [s]ine.\r\n");
    exit(0);
  }

  printf("Please enter frequency: (1-1000)\r\n");
  scanf("%s",freq);
  if((atoi(freq) <= 1 || atoi(freq) > 1000))//frequency is not correct
  { 
    printf("Please chose frequency between 1 and 1000 (Hz).\r\n");
    exit(0);
  }

  printf("Please enter amplitude: (0.1-3.2)\r\n");
  scanf("%s",amp);
  if((atof(amp) < 0.0 || atof(amp) > 3.2))//amplitude is not correct
  {
    printf("Please chose amplitude between 0.1 and 3.2 (V).\r\n");
    exit(0);
  }


  //create message to server
  //message = (char *)malloc(8*sizeof(char)+1);//set me
  strcpy(message,type);
  strcat(message," ");
  strcat(message,freq);
  strcat(message," ");
  strcat(message,amp);
  strcat(message," ");
  strcat(message,"\0");
  printf("Message: %s\n", message);


  //Begin sockcontrolet transmission
  //generic socket code

  if (-1 == CommSock)
  {
    printf("Error: cannot create socket.");
    exit(0);
  }

  memset(&stSockAddr, 0, sizeof(stSockAddr));

  stSockAddr.sin_family = AF_INET;
  stSockAddr.sin_port = htons(1100);
  Res = inet_pton(AF_INET, "128.172.167.185", &stSockAddr.sin_addr);/////SET IP HERE/////

  if (0 > Res)
  {
    printf("Error: invalid address family.");
    close(CommSock);
    exit(0);
  }
  else if (0 == Res)
  {
    printf("Error: invalid IP address.");
    close(CommSock);
    exit(0);
  }

  if (-1 == connect(CommSock, (struct sockaddr *)&stSockAddr, sizeof(stSockAddr)))
  {
    printf("Error: connection failed.");
    close(CommSock);
    exit(0);
  }

  printf("Connection established.\r\n");
    
  
  //Begin control loop

  //control[0]='\0';
  flag = 1;
      
  while (control != 'e')
  {
    if(flag==1)
    {
      send(CommSock ,message,strlen(message),0);
      flag = 0;
    }
	  if(flag2==0)
    {
      printf("Would you like to [e]xit or input [n]ew data?\r\n");
      fflush(stdin);
      scanf("%c",&control);
    }
    else
      flag2--;

    if(control=='n')
    {
      printf("Please enter wave type: [p]ulse/[s]ine\r\n");
      scanf("%s",type);
      if((strcmp(type,"p") != 0) && (strcmp(type,"s")!= 0))//type is not correct
      {
        printf("Please chose between [p]ulse and [s]ine.\r\n");
        exit(0);
      }

      printf("Please enter frequency: (1-1000)\r\n");
      scanf("%s",freq);
      if(((atoi(freq) <= 1) || atoi(freq) > 1000))//frequency is not correct
      { 
        printf("Please chose frequency between 1 and 1000 (Hz).\r\n");
        exit(0);
      }

      printf("Please enter amplitude: (0.1-3.2)\r\n");
      scanf("%s",amp);
      if(((atof(amp) < 0.0 || atof(amp) > 3.2)))//amplitude is not correct
      {
        printf("Please chose amplitude between 0.1 and 3.2 (V).\r\n");
        exit(0);
      }
      flag = 1;
      strcpy(message,"");
      strcpy(message,type);
      strcat(message," ");
      strcat(message,freq);
      strcat(message," ");
      strcat(message,amp);
      strcat(message," ");
      strcat(message,"\0");
      printf("Message: %s\n", message);
    }
  }//end while
  //send terminate message
  strcpy(message,"e");
  send(CommSock ,message,strlen(message),0);
  (void) shutdown(CommSock, SHUT_RDWR);

  close(CommSock);
  return 1;
}

