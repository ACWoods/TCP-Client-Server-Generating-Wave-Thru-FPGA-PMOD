#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"
#include "pthread.h"
#include "string.h"
#include "sys/socket.h"
#include "sys/types.h"
#include "netinet/in.h"
#include "arpa/inet.h"
#include "fcntl.h"
#include "sys/mman.h"
//#include "time.h"
#include "math.h"

pthread_mutex_t lock= PTHREAD_MUTEX_INITIALIZER;

//Memory defines
#define SBASE 0x42000000 //SPI base address
#define SPISR 0x64 //status register offset
#define SPICR 0x60 //control register offset
#define SPISSR 0x70 //slave select register offset
#define SPIDTR 0x68 //transmit register offset
#define SPIDRR 0x6C //receive register offset
#define SPISRR 0x40 //software reset offset

//Wave defines
#define MAP_SIZE 4096UL
#define MAP_MASK (MAP_SIZE -1)
#define MV 3.2 //voltage
#define BASE 45000000 //high f wait
#define PD 37000000 //low f wait
#define SDA 97000//sine frequency multipliers
#define SDB 88000
#define SDC 82000
#define SDD 74500
#define SDE 65000
#define SDF 58000
#define SDG 51000
#define SDH 40000
#define SDI 29000
#define SDJ 24000


//Global variables
int type=-1;
double amplitude = 0.0;
double frequency = 0.0;
int pwait = 0;
char temp[3][32];


//Global lookup tables
uint8_t sines[128] = //generated with www.daycounter.com sine lookup table tool
{
	0x0,0x0,0x1,0x1,0x2,0x4,0x5,0x7,
	0xA,0xC,0xF,0x12,0x15,0x19,0x1D,0x21,
	0x25,0x2A,0x2F,0x34,0x39,0x3E,0x43,0x49,
	0x4F,0x55,0x5A,0x61,0x67,0x6D,0x73,0x79,	
	0x80,0x86,0x8C,0x92,0x98,0x9E,0xA5,0xAA,
	0xB0,0xB6,0xBC,0xC1,0xC6,0xCB,0xD0,0xD5,
	0xDA,0xDE,0xE2,0xE6,0xEA,0xED,0xF0,0xF3,
	0xF5,0xF8,0xFA,0xFB,0xFD,0xFE,0xFE,0xFF,
	0xFF,0xFF,0xFE,0xFE,0xFD,0xFB,0xFA,0xF8,
	0xF5,0xF3,0xF0,0xED,0xEA,0xE6,0xE2,0xDE,
	0xDA,0xD5,0xD0,0xCB,0xC6,0xC1,0xBC,0xB6,
	0xB0,0xAA,0xA5,0x9E,0x98,0x92,0x8C,0x86,
	0x80,0x79,0x73,0x6D,0x67,0x61,0x5A,0x55,
	0x4F,0x49,0x43,0x3E,0x39,0x34,0x2F,0x2A,
	0x25,0x21,0x1D,0x19,0x15,0x12,0xF,0xC,
	0xA,0x7,0x5,0x4,0x2,0x1,0x1,0x0
};
uint8_t sinecpy[128];

uint8_t pulses[2] = {0x00,0xFF};//on and off
uint8_t pulsecpy[2];

void *output(void * threadid)
{

	int x = 0, y=0, z=0;
	int memfd;
   
	
   	off_t dev_b = SBASE;//base address
    off_t dev_spisr  = SBASE + SPISR;//status reg
	off_t dev_spicr  = SBASE + SPICR;//control reg
	off_t dev_spissr  = SBASE + SPISSR;//slave select reg
    off_t dev_spidtr  = SBASE + SPIDTR;//transmit reg
    off_t dev_spidrr  = SBASE + SPIDRR;//receive reg
	off_t dev_spisrr = SBASE + SPISRR;//software reset reg

	
	void *base;
	void *dev_status;
	void *dev_control;
    void *dev_select;
    void *dev_tx;
	void *dev_rx;
	void *dev_reset;
	
	
	//Start of Memory Operations
	memfd = open("/dev/mem", O_RDWR | O_SYNC);
	
	if(memfd == -1)
	{
		printf("Error: cannot open memory.");
		return 0;//error
	}

	base = mmap(0, MAP_SIZE,PROT_READ | PROT_WRITE, MAP_SHARED, memfd, dev_b & ~MAP_MASK);


	if(base == (void*)-1)
	{
		printf("Error: cannot map the memory to user space.");
		return 0;//error
	}
	
	dev_status = base + (dev_spisr & MAP_MASK);
	dev_control = base + (dev_spicr & MAP_MASK);
	dev_select = base + (dev_spissr & MAP_MASK);
	dev_tx = base + (dev_spidtr & MAP_MASK);
	dev_rx = base + (dev_spidrr & MAP_MASK);
	dev_reset = base + (dev_spisrr & MAP_MASK);
	
	//End of Memory Operations
	
	printf("End of mapping.\r\n");
	printf("Base mapped to: %p\r\n",base);


	//Set SPI settings
	 *((volatile int *)dev_reset) = 0x0000000A;//reset software
 	 *((volatile int *)dev_select) = 0x00000001;//slave select high 
	 *((volatile int *)dev_control) = 0x00000086;//control reg setting 


	//Wave output operations
	while(1)
	{
		while(type==0)//sine wave
		{
			  
			//Frequency calculation
			if(frequency <= 100)		
				for(y=0;y<(SDA*(1/frequency));y++);		
			else if(frequency <=200)
				for(y=0;y<(SDB*(1/frequency));y++);
			else if(frequency <= 300)
	            for(y=0;y<(SDC*(1/frequency));y++);
	        else if( frequency <= 400)
				for(y=0;y<(SDD*(1/frequency));y++); 
			else if(frequency <= 500)
	            for(y=0;y<(SDE*(1/frequency));y++);
	        else if(frequency <= 600)
	            for(y=0;y<(SDF*(1/frequency));y++);
	        else if(frequency <= 700)
	            for(y=0;y<(SDG*(1/frequency));y++);
	        else if(frequency <= 800)
	            for(y=0;y<(SDH*(1/frequency));y++);
	        else if(frequency <= 900)
	            for(y=0;y<(SDI*(1/frequency));y++);
	        else
	        	for(y=0;y<(SDJ*(1/frequency));y++);

			//increment counter
			if(x+1 == 128)
			   x = 0;
			else
			   x++;

			//Transmission   			
			*((volatile int *)dev_select) = 0x00000000;	//slave select 0 (begin transmission)
			
			*((volatile int *)dev_tx) = (0xB000 | sinecpy[x]);//send 16 bits//A000
	
			while((*((volatile int *)dev_status) & 0x00000004) != 0x00000004);//wait for tx reg empty
			
			*((volatile int *)dev_select) = 0x00000001;//slave select 1 (end transmission)
		}

		while(type==1)//pulse wave
		{

			//Frequency calculation
			for(y=0;y<pwait;y++);
			
			if(z+1 == 2)
			{
				z = 0;
			}
			else
			{
				z++;
			}

			//Transmission
			*((volatile int *)dev_select) = 0x00000000;//slave select 0 (begin transmission)

			*((volatile int *)dev_tx) = (0xB000 | pulsecpy[z]);//send 16 bits//A0000

			while((*((volatile int *)dev_status) & 0x00000004) != 0x00000004);//wait for tx reg empty

			*((volatile int *)dev_select) = 0x00000001;//slave select 1 (end transmission)
		}
	}
}//end output


int main()
{

	//Variables
	struct sockaddr_in stSockAddr;
	int CommSock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	int ConnectSock;        
	char buff[32]; 
	int mythread;
	int x=0;
	int y=0;
	int z=0;
	pthread_t thread[1];

	//Socket setup
	//generic socket code

	printf("Server started, waiting for connections.\r\n");

	if(-1 == CommSock)
	{
	  printf("Error: cannot create socket.");
	  exit(0);
	}

	memset(&stSockAddr, 0, sizeof(stSockAddr));

	stSockAddr.sin_family = AF_INET;
	stSockAddr.sin_port = htons(1100);
	stSockAddr.sin_addr.s_addr = htonl(INADDR_ANY);

	if(-1 == bind(CommSock,(struct sockaddr *)&stSockAddr, sizeof(stSockAddr)))
	{
	  printf("Error: socket bind failed.");
	  close(CommSock);
	  exit(0);
	}

	if(-1 == listen(CommSock, 10))
	{
	  printf("Error: listen failed.");
	  close(CommSock);
	  exit(0);
	}

	ConnectSock = accept(CommSock, NULL, NULL);
	if(0 > ConnectSock)
	{     
		printf("Error: socket accept failed.");
		close(CommSock);
		exit(0);
	}

	printf("Connection successful.\r\n");

	//Thread creation

	mythread = pthread_create(&thread[1], NULL, output, NULL);//create thread for output process
	if (mythread)
	{
	 printf("ERROR: pthread code- %d", mythread);
	 exit(0);
	}

	printf("Thread created.\r\n");

	while(1)//main loop
	{   
		for(x = 0; x < 32; x++)//clean buffer
		{
			buff[x] = '\0';
		}
		for(y = 0; y < 3; y++)//clean temp
		{
			for(x = 0; x < 32; x++)
				temp[y][x] = '\0';
		}


		do//
		{
			mythread  =  read(ConnectSock,buff,sizeof(buff));//send data to output process/thread
		}while(mythread<=0);

		//reset counters
		z=0;
		x=0;
		y=0;
		while(y < 3)//clean out input buffers
		{
			temp[y][x] = buff[z];
			z++;
			x++;
			if(buff[z] == ' ')//if space detected
			{
				temp[y][x] = '\0';
				x = 0;
				y++;
			}
		}
		
		if(temp[0][0] == 'e')//check for end program
			break;

		//Update wave characteristics

		pthread_mutex_lock(&lock);//lock thread for update (needed for while loop in output function)
		
		if(strcmp(temp[0],"s") == 0)//sine
			type = 0;
		if(strcmp(temp[0],"p") == 0)//pulse
			type = 1;  
		pthread_mutex_unlock(&lock);//clear lock on thread
		pthread_mutex_destroy(&lock);

		frequency = (double)atof(temp[1]);//read frequency from message
		amplitude = (double)atof(temp[2]);//read amplitude from message

		if(frequency > 100)
			pwait = (int)(BASE*(pow(frequency,-1.016)));//set high f wave frequency
		else 
			pwait =(1/frequency)*PD;//set low f wave frequency

		pulsecpy[1] = (int)(pulses[1] * amplitude/MV);//set pulse wave amplitude

		for(x = 0; x < 128; x++)
		{
			sinecpy[x] = (int)(sines[x] * amplitude/MV);//set sine wave amplitude
		}


	}//end while

	
	//Close sockets
	close(ConnectSock);
	close(CommSock);

	return 1;  
}//end main
